const connection = require('../config/connection')
const {promisify} = require('util')

const bcrypt = require('bcryptjs')

const promise_connection = promisify(connection.query).bind(connection)

exports.getUser = async ()=>{

    let query = "SELECT id, email_id, name FROM users WHERE type != 'admin'"
    return await promise_connection(query);
}

exports.login = async (email, password) => {
    try {
        // email = sanitizeInput(email);
        // password = sanitizeInput(password);

        const query = "SELECT id,password,type FROM users WHERE email_id = ?";
        const [rows] = await promise_connection(query, [email]);

        if (rows.length === 0) {
            return {
                status: false
            };
        }

        const hashedPassword = rows.password;

        const isMatch = await bcrypt.compare(password, hashedPassword);

        if (!isMatch) {
            return {
                status: false
            };
        }

        return {
            status: true,
            userType: rows.type,
            userId: rows.id
        };
    } catch (error) {
        console.error('Login error:', error);
        return {
            status: false
        }; 
    }
}

exports.createUser = async (name, email, password) => {
    try {
        const checkQuery = 'SELECT * FROM users WHERE email_id = ?';
        const [existingUser] = await promise_connection(checkQuery, [email]);
        console.log('execur ', existingUser)
        
        if (existingUser || existingUser?.length > 0) {
            return {
                status: false,
                message: "User already exists"
            };
        }

        const salt = await bcrypt.genSalt(10);
        const hashedPassword = await bcrypt.hash(password, salt);

        const insertQuery = `
            INSERT INTO users (name, email_id, password, type)
            VALUES (?, ?, ?, 'user')
        `;

        const result = await promise_connection(insertQuery, [name, email, hashedPassword]);

        return {
            status: true,
            message: "User Created Successfully",
            id: result.insertId
        }; 
    } catch (error) {
        console.error('Error creating user:', error);
        return {
            status: false,
            message: "Failed to create user"
        };
    }
};

exports.deleteUser = async (id) => {
    try {
        const checkQuery = 'DELETE FROM users WHERE id = ?';
        const existingUser = await promise_connection(checkQuery, [id]);

        if (existingUser) {
            return {
                status: true,
                message: "Deleted user successfully"
            };
        }else{
            return {
                status: false,
                message: "Failed to delete user"
            };
        }

    } catch (error) {
        console.error('Error creating user:', error);
        return {
            status: false,
            message: "Failed to delete user"
        };
    }
};