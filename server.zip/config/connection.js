const mysql = require('mysql')

const connection = mysql.createConnection({
    host: 'localhost',
    password: '',
    user: 'root',
    database: 'meeting_room'
})
connection.connect((err)=> {
    if(err){
        throw err;
    }else{
        console.log('connected to db')
    }
})

module.exports = connection